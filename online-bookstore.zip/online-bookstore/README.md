# online-bookstore
REST API for an online bookstore with CRUD operations - Spring Boot Implementation

Implementation -
http://localhost:8080/bookstore

http://localhost:8080/bookstore/welcome

http://localhost:8080/bookstore/addbook

http://localhost:8080/bookstore/getallbooks

http://localhost:8080/bookstore/getbook/{Id}

http://localhost:8080/bookstore/updatebook

http://localhost:8080/bookstore/deletebook/{Id}

http://localhost:8080/bookstore/buybooks


Database - H2 DB In Mememory Spring Boot BuiltIn
http://localhost:8080/h2-console/

JDBC URL - jdbc:h2:mem:testdb

sa/admin

Assumptions -
1. 
