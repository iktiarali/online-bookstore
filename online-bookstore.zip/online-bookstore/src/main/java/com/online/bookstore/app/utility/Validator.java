package com.online.bookstore.app.utility;

import com.online.bookstore.app.entity.Book;

public class Validator {
	// Try using validator service to validate the requests /books
	public static boolean validateBook(Book book) {
		
		return true;
	}
}
